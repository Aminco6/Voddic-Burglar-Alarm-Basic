<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Loop over all canvases and apply the scratch effect to each
        {% for i in all_games %}
            const canvas = document.getElementById('scratchCanvas-{{ i.game_pk }}');
            if (canvas) {
                const ctx = canvas.getContext('2d');
                const scratcher = new ScratchCard(canvas, ctx);

                // Setup canvas size and scratch effect
                canvas.width = 300;
                canvas.height = 300;
                ctx.fillStyle = "#ddd";
                ctx.fillRect(0, 0, canvas.width, canvas.height);
                
                scratcher.init();
            }
        {% endfor %}
    });

    class ScratchCard {
        constructor(canvas, ctx) {
            this.canvas = canvas;
            this.ctx = ctx;
            this.isDrawing = false;
        }

        init() {
            this.canvas.addEventListener('mousedown', this.startScratching.bind(this));
            this.canvas.addEventListener('mousemove', this.scratching.bind(this));
            this.canvas.addEventListener('mouseup', this.stopScratching.bind(this));
            this.canvas.addEventListener('mouseout', this.stopScratching.bind(this));
        }

        startScratching(event) {
            this.isDrawing = true;
            this.scratching(event);
        }

        stopScratching() {
            this.isDrawing = false;
        }

        scratching(event) {
            if (!this.isDrawing) return;

            const rect = this.canvas.getBoundingClientRect();
            const x = event.clientX - rect.left;
            const y = event.clientY - rect.top;

            this.ctx.globalCompositeOperation = 'destination-out';
            this.ctx.beginPath();
            this.ctx.arc(x, y, 20, 0, Math.PI * 2, false);
            this.ctx.fill();
        }
    }
</script>




var downloadButton = document.getElementById("t");

var counter = 10;

var newElement = document.createElement("p");

newElement.innerHTML = "10 sec";

var id;

downloadButton.parentNode.replaceChild(newElement, downloadButton);

function startDownload() {

    this.style.display = 'none';

    id = setInterval(function () {

        counter--;

        if (counter < 0) {

            newElement.parentNode.replaceChild(downloadButton, newElement);

            clearInterval(id);

        } else {

            newElement.innerHTML = +counter.toString() + " second.";

        }

    }, 1000);

};

var clickbtn = document.getElementById("postButton");

clickbtn.onclick = startDownload;
